Exceptions Reference
====================

.. autoclass:: Numberjack.ConstraintNotSupportedError
.. autoclass:: Numberjack.UnsupportedSolverFunction
.. autoclass:: Numberjack.InvalidEncodingException
.. autoclass:: Numberjack.InvalidConstraintSpecification
.. autoclass:: Numberjack.ModelSizeError