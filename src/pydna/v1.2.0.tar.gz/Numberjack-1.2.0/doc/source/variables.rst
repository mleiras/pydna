Variables Reference
===================

.. autoclass:: Numberjack.Variable
   :members:
   :inherited-members:


.. autoclass:: Numberjack.VarArray
   :members:
   :special-members: __lt__,__le__,__gt__,__ge__,__eq__


.. autoclass:: Numberjack.Matrix
   :members:

