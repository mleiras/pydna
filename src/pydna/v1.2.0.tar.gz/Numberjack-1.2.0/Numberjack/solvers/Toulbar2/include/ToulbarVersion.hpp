// Cmake generated version
#define Toulbar_VERSION "0.9.8.0-master-325c5b4 (1455555791)"
