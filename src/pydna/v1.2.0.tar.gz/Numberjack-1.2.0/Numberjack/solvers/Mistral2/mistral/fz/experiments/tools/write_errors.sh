tools/parse.py -key allInstancesUnderWorld -showerror all | grep .fzn > bugs.txt 
